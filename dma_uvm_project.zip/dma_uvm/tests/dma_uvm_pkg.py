"""UVM environment for the DMA controller, written with pyuvm on cocotb.

Structure: test -> env -> (agent: sequencer, driver, monitor) + scoreboard + coverage.
"""
import random
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, FallingEdge, Timer
from pyuvm import (uvm_sequence_item, uvm_sequence, uvm_sequencer, uvm_driver, uvm_monitor,
                   uvm_agent, uvm_env, uvm_test, uvm_subscriber, uvm_analysis_port,
                   ConfigDB, UVMError)
import pyuvm

MEM_BYTES = 4096
WORDS = MEM_BYTES // 4
REG_SRC, REG_DST, REG_LEN, REG_CTRL, REG_STATUS, REG_CLEAR = 0x00, 0x04, 0x08, 0x0C, 0x10, 0x14


def pattern(seed, i):
    return (seed ^ (i * 0x9E3779B1)) & 0xFFFFFFFF


# ----------------------------------------------------------------------------- BFM
class DmaBfm:
    """Pin-level access to the DUT (APB master and backdoor memory)."""

    def __init__(self, dut):
        self.dut = dut

    async def start_clock(self):
        cocotb.start_soon(Clock(self.dut.clk, 10, "ns").start())

    async def reset(self):
        d = self.dut
        d.rst_n.value = 0
        d.psel.value = 0; d.penable.value = 0; d.pwrite.value = 0
        d.paddr.value = 0; d.pwdata.value = 0
        d.bd_we.value = 0; d.bd_addr.value = 0; d.bd_wdata.value = 0
        for _ in range(4):
            await RisingEdge(d.clk)
        d.rst_n.value = 1
        for _ in range(2):
            await RisingEdge(d.clk)

    async def apb_write(self, addr, data):
        d = self.dut
        await RisingEdge(d.clk)
        d.psel.value = 1; d.pwrite.value = 1; d.paddr.value = addr; d.pwdata.value = data; d.penable.value = 0
        await RisingEdge(d.clk)
        d.penable.value = 1
        await RisingEdge(d.clk)
        d.psel.value = 0; d.penable.value = 0; d.pwrite.value = 0

    async def apb_read(self, addr):
        d = self.dut
        await RisingEdge(d.clk)
        d.psel.value = 1; d.pwrite.value = 0; d.paddr.value = addr; d.penable.value = 0
        await RisingEdge(d.clk)
        d.penable.value = 1
        await Timer(1, "ns")
        value = int(d.prdata.value)
        await RisingEdge(d.clk)
        d.psel.value = 0; d.penable.value = 0
        return value

    async def mem_write(self, byte_addr, data):
        d = self.dut
        await RisingEdge(d.clk)
        d.bd_we.value = 1; d.bd_addr.value = byte_addr; d.bd_wdata.value = data
        await RisingEdge(d.clk)
        d.bd_we.value = 0

    def snapshot(self):
        """Read the whole RAM (read-only hierarchical access, used by the monitor)."""
        ram = self.dut.ram
        return [int(ram[i].value) for i in range(WORDS)]


# ----------------------------------------------------------------------------- transaction
class DmaItem(uvm_sequence_item):
    def __init__(self, name="dma_item"):
        super().__init__(name)
        self.src = 0; self.dst = 0; self.length = 1; self.irq_en = 0; self.seed = 0

    def randomize_valid(self):
        self.length = random.choice([1, 2, 3, 8, 16, 33, 64, 100])
        max_start = WORDS - self.length
        a = random.randint(0, max_start)
        b = random.randint(0, max_start)
        self.src, self.dst = 4 * a, 4 * b           # overlap allowed: reference model is exact
        self.irq_en = random.randint(0, 1)
        self.seed = random.getrandbits(32)

    def __str__(self):
        return f"src={self.src:#x} dst={self.dst:#x} len={self.length} irq_en={self.irq_en}"


class DmaObservation:
    """What the monitor saw for one START: config, memory before, memory after, final status."""
    def __init__(self, src, dst, length, irq_en, before, after, status, irq):
        self.src, self.dst, self.length, self.irq_en = src, dst, length, irq_en
        self.before, self.after, self.status, self.irq = before, after, status, irq


# ----------------------------------------------------------------------------- sequences
class RandomSeq(uvm_sequence):
    def __init__(self, name="random_seq", count=40):
        super().__init__(name)
        self.count = count

    async def body(self):
        for _ in range(self.count):
            item = DmaItem()
            await self.start_item(item)
            item.randomize_valid()
            await self.finish_item(item)


class ErrorSeq(uvm_sequence):
    """Directed illegal configurations: each must set ERR and leave memory untouched."""
    async def body(self):
        cases = [
            dict(src=0x100, dst=0x800, length=0),              # zero length
            dict(src=0x101, dst=0x800, length=4),              # unaligned src
            dict(src=0x100, dst=0x802, length=4),              # unaligned dst
            dict(src=0x100, dst=0xFF8, length=4),              # dst runs past end
            dict(src=0xFF8, dst=0x100, length=4),              # src runs past end
            dict(src=0x100, dst=0x800, length=0xFFFFFFFF),     # huge length (overflow check)
        ]
        for c in cases:
            item = DmaItem()
            await self.start_item(item)
            item.src, item.dst, item.length = c["src"], c["dst"], c["length"]
            item.irq_en = 0; item.seed = random.getrandbits(32)
            await self.finish_item(item)


# ----------------------------------------------------------------------------- agent parts
class DmaDriver(uvm_driver):
    def build_phase(self):
        self.bfm = ConfigDB().get(self, "", "BFM")

    async def run_phase(self):
        while True:
            item = await self.seq_item_port.get_next_item()
            await self.drive(item)
            self.seq_item_port.item_done()

    async def drive(self, item):
        b = self.bfm
        valid_range = item.length < WORDS and item.src // 4 + item.length <= WORDS
        if valid_range:                                         # fill the source region
            for i in range(item.length):
                await b.mem_write(item.src + 4 * i, pattern(item.seed, i))
        await b.apb_write(REG_SRC, item.src)
        await b.apb_write(REG_DST, item.dst)
        await b.apb_write(REG_LEN, item.length)
        await b.apb_write(REG_CTRL, 1 | (item.irq_en << 1))
        for _ in range(5000):                                   # wait for not busy
            st = await b.apb_read(REG_STATUS)
            if not st & 1:
                break
        else:
            raise UVMError("DMA timeout")
        await b.apb_write(REG_CLEAR, 3)
        await b.apb_write(REG_CTRL, 0)


class DmaMonitor(uvm_monitor):
    def build_phase(self):
        self.bfm = ConfigDB().get(self, "", "BFM")
        self.ap = uvm_analysis_port("ap", self)

    async def run_phase(self):
        d = self.bfm.dut
        shadow = {REG_SRC: 0, REG_DST: 0, REG_LEN: 0}
        irq_en = 0
        while True:
            await FallingEdge(d.clk)                            # inputs are stable here
            if not (int(d.psel.value) and int(d.penable.value) and int(d.pwrite.value)):
                continue
            a, w = int(d.paddr.value), int(d.pwdata.value)
            if a in shadow:
                shadow[a] = w
            elif a == REG_CTRL:
                irq_en = (w >> 1) & 1
                if w & 1:
                    await self.observe(dict(shadow), irq_en)

    async def observe(self, cfg, irq_en):
        d = self.bfm.dut
        before = self.bfm.snapshot()
        for _ in range(5000):                                   # wait for DONE or ERR
            await FallingEdge(d.clk)
            if int(d.u_dma.done_q.value) or int(d.u_dma.err_q.value):
                break
        irq = int(d.irq.value)
        status = (int(d.u_dma.err_q.value) << 2) | (int(d.u_dma.done_q.value) << 1)
        after = self.bfm.snapshot()
        self.ap.write(DmaObservation(cfg[REG_SRC], cfg[REG_DST], cfg[REG_LEN], irq_en,
                                     before, after, status, irq))


class DmaAgent(uvm_agent):
    def build_phase(self):
        self.sequencer = uvm_sequencer("sequencer", self)
        self.driver = DmaDriver("driver", self)
        self.monitor = DmaMonitor("monitor", self)

    def connect_phase(self):
        self.driver.seq_item_port.connect(self.sequencer.seq_item_export)


# ----------------------------------------------------------------------------- scoreboard + coverage
class DmaScoreboard(uvm_subscriber):
    """Compares every observed transfer against an independent reference model."""
    def build_phase(self):
        self.checked = 0
        self.errors = 0

    @staticmethod
    def classify(src, dst, length):
        if length == 0:
            return "err_zero_len"
        if src % 4 or dst % 4:
            return "err_unaligned"
        if src + 4 * length > MEM_BYTES or dst + 4 * length > MEM_BYTES:
            return "err_range"
        return "ok"

    def write(self, obs):
        self.checked += 1
        kind = self.classify(obs.src, obs.dst, obs.length)
        expect = list(obs.before)
        if kind == "ok":
            words = [obs.before[obs.src // 4 + i] for i in range(obs.length)]   # snapshot semantics
            # the DMA copies word by word, so with overlapping regions the reference does the same
            expect = list(obs.before)
            for i in range(obs.length):
                expect[obs.dst // 4 + i] = expect[obs.src // 4 + i]
            exp_status = 0b010
        else:
            exp_status = 0b100
        if obs.status != exp_status:
            self.errors += 1
            self.logger.error(f"status {obs.status:03b} expected {exp_status:03b} for {kind} "
                              f"(src={obs.src:#x} dst={obs.dst:#x} len={obs.length})")
        if obs.after != expect:
            diffs = [i for i in range(WORDS) if obs.after[i] != expect[i]]
            self.errors += 1
            self.logger.error(f"memory mismatch for {kind}: {len(diffs)} words differ, first at word {diffs[0]}")
        exp_irq = 1 if (kind == "ok" and obs.irq_en) else 0
        if obs.irq != exp_irq:
            self.errors += 1
            self.logger.error(f"irq {obs.irq} expected {exp_irq} for {kind}")
        coverage.sample(kind, obs)

    def check_phase(self):
        self.logger.info(f"scoreboard: {self.checked} transfers checked, {self.errors} errors")
        if self.errors:
            raise UVMError(f"{self.errors} scoreboard errors")
        if self.checked == 0:
            raise UVMError("scoreboard saw no transfers")


class Coverage:
    """Small functional-coverage collector (bins hit by observed transfers)."""
    LEN_BINS = [("len_1", lambda n: n == 1), ("len_2_8", lambda n: 2 <= n <= 8),
                ("len_9_32", lambda n: 9 <= n <= 32), ("len_33_64", lambda n: 33 <= n <= 64),
                ("len_65_plus", lambda n: 65 <= n < WORDS)]
    KINDS = ["ok", "err_zero_len", "err_unaligned", "err_range"]

    def __init__(self):
        self.hit = {}

    def sample(self, kind, obs):
        self.hit[("kind", kind)] = self.hit.get(("kind", kind), 0) + 1
        if kind == "ok":
            self.hit[("irq_en", obs.irq_en)] = self.hit.get(("irq_en", obs.irq_en), 0) + 1
            for name, f in self.LEN_BINS:
                if f(obs.length):
                    self.hit[("len", name)] = self.hit.get(("len", name), 0) + 1
            if obs.src // 4 < obs.dst // 4 < obs.src // 4 + obs.length:
                self.hit[("overlap", "dst_in_src")] = self.hit.get(("overlap", "dst_in_src"), 0) + 1

    def report(self, want):
        total = [("kind", k) for k in want["kinds"]] + [("len", n) for n, _ in self.LEN_BINS if n in want["lens"]] \
                + [("irq_en", 0), ("irq_en", 1)] * (1 if want["lens"] else 0)
        missing = [b for b in total if b not in self.hit]
        pct = 100.0 * (len(total) - len(missing)) / len(total) if total else 100.0
        return pct, missing


coverage = Coverage()


# ----------------------------------------------------------------------------- env and tests
class DmaEnv(uvm_env):
    def build_phase(self):
        self.agent = DmaAgent("agent", self)
        self.scoreboard = DmaScoreboard("scoreboard", self)

    def connect_phase(self):
        self.agent.monitor.ap.connect(self.scoreboard.analysis_export)


class DmaBaseTest(uvm_test):
    want = {"kinds": ["ok"], "lens": []}

    def build_phase(self):
        self.env = DmaEnv("env", self)

    async def run_phase(self):
        self.raise_objection()
        await self.run_sequences()
        for _ in range(20):
            await RisingEdge(self.env.agent.driver.bfm.dut.clk)
        self.drop_objection()

    def check_phase(self):
        pct, missing = coverage.report(self.want)
        self.logger.info(f"functional coverage: {pct:.0f}%  missing: {missing if missing else 'none'}")
        if missing:
            raise UVMError(f"coverage holes: {missing}")


class SmokeTest(DmaBaseTest):
    want = {"kinds": ["ok"], "lens": []}

    async def run_sequences(self):
        await RandomSeq("smoke", count=3).start(self.env.agent.sequencer)


class RandomTest(DmaBaseTest):
    want = {"kinds": ["ok"], "lens": ["len_1", "len_2_8", "len_9_32", "len_33_64", "len_65_plus"]}

    async def run_sequences(self):
        await RandomSeq("random", count=60).start(self.env.agent.sequencer)


class ErrorTest(DmaBaseTest):
    want = {"kinds": ["err_zero_len", "err_unaligned", "err_range"], "lens": []}

    async def run_sequences(self):
        await ErrorSeq("errors").start(self.env.agent.sequencer)


class RegressionTest(DmaBaseTest):
    want = {"kinds": ["ok", "err_zero_len", "err_unaligned", "err_range"],
            "lens": ["len_1", "len_2_8", "len_9_32", "len_33_64", "len_65_plus"]}

    async def run_sequences(self):
        s = self.env.agent.sequencer
        await ErrorSeq("errors").start(s)
        await RandomSeq("random", count=80).start(s)
