import os
import cocotb
from pyuvm import uvm_root, ConfigDB
from dma_uvm_pkg import DmaBfm, SmokeTest, RandomTest, ErrorTest, RegressionTest  # noqa: F401


@cocotb.test()
async def run_uvm(dut):
    bfm = DmaBfm(dut)
    await bfm.start_clock()
    await bfm.reset()
    ConfigDB().set(None, "*", "BFM", bfm)
    await uvm_root().run_test(os.environ.get("UVM_TESTNAME", "RegressionTest"), keep_set={ConfigDB})
