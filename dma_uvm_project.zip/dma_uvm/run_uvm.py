"""Build the DMA RTL with Verilator and run the pyuvm tests: python3 run_uvm.py [TestName ...]"""
import os
import sys
from pathlib import Path
from cocotb_tools.runner import get_runner

here = Path(__file__).resolve().parent
os.environ["PATH"] = f"{here / 'bin'}:{os.environ['PATH']}"        # pip Verilator shim
tests = sys.argv[1:] or ["SmokeTest", "ErrorTest", "RandomTest", "RegressionTest"]

runner = get_runner("verilator")
runner.build(sources=[here / "rtl/dma_ctrl.sv", here / "rtl/dma_soc.sv"], hdl_toplevel="dma_soc",
             build_dir=here / "build", always=False,
             build_args=["--public-flat-rw", "-Wno-fatal", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-Wno-TIMESCALEMOD"])
failed = []
for t in tests:
    os.environ["UVM_TESTNAME"] = t
    res = runner.test(hdl_toplevel="dma_soc", test_module="test_dma_uvm", test_dir=str(here / "tests"),
                      build_dir=here / "build", results_xml=here / "build" / f"results_{t}.xml")
    print(f"##### {t}: done")
    import xml.etree.ElementTree as ET
    x = ET.parse(here / "build" / f"results_{t}.xml")
    bad = [c for c in x.iter("testcase") if c.find("failure") is not None or c.find("error") is not None]
    if bad:
        failed.append(t)
print("FAILED:" if failed else "ALL UVM TESTS PASSED", failed or "")
sys.exit(1 if failed else 0)
